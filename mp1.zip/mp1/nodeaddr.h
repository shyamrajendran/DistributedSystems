/**********************
*
* Progam Name: MP1. Membership Protocol
* 
* Current file: nodeaddr.h
* About this file: Header file.
* 
***********************/

#ifndef __NODEADDR_H_
#define __NODEADDR_H_
/* nodeID */
typedef struct address{
	char addr[6];
} address;

#endif /* __NODEADDR_H_ */
