/**********************
*
* Progam Name: MP1. Membership Protocol
*
* Current file: app.h
* About this file: Header file.
* 
***********************/

#ifndef _APP_H_
#define _APP_H_

#include "mp1_node.h"

/* DO NOT group[] ACCESS FROM INSIDE MP_NODE.C */
member *group;

#endif /* _APP_H__ */
